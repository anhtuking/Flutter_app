import 'package:hive_flutter/hive_flutter.dart';
// import 'package:intl/intl.dart';

class LocalStorageHelper {
  LocalStorageHelper._internal();
  static final LocalStorageHelper _shared = LocalStorageHelper._internal();
  factory LocalStorageHelper() {
    return _shared;
  }

  Box<dynamic>? hiveBox;

  static initLocalStorageHelper() async {
    _shared.hiveBox = await Hive.openBox('TravelApp');
  }

  static dynamic getValue(String key) {
    return _shared.hiveBox?.get(key);
  }

  static setValue(String key, dynamic val) {
    _shared.hiveBox?.put(key, val);
  }

  static deleteValue(String key) {
    _shared.hiveBox?.delete(key);
  }

  // generate a receipt
  // String displayReceipt() {
  //   final receipt = StringBuffer();
  //   receipt.writeln("Here's your receipt.");
  //   receipt.writeln();

  //   // format the date in include up to seconds only
  //   String formattedDate = 
  //       DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now());

  //   receipt.writeln(formattedDate);
  //   receipt.writeln();
  //   receipt.writeln("-----------");

  //   return receipt.toString();

  // }
  // format double value into money
  // String _formatPrice(double price){
  //   return "\$${price.toStringAsFixed(2)}";
  // }
  // format list of addons into a string summary
  // String _formatAddons(List<Addon> addons){
  //   return addons
  //       .map((addon) => "${addon.name} (${_formatPrice(addon.price)})")
  //       .join(", ");
  // }
}
