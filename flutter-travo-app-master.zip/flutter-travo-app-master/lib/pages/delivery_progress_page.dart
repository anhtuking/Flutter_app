import 'package:flutter/material.dart';
import 'package:travo_app_source/representation/screen/main_app.dart';
// import 'package:travo_app_source/components/my_receipt.dart';
import '../representation/widgets/app_bar_container.dart';
import '../core/constants/dimension_constants.dart';
import '../core/constants/textstyle_ext.dart';

class DeliveryProgressPage extends StatefulWidget {
  const DeliveryProgressPage({Key? key}) : super(key: key);

  @override
  State<DeliveryProgressPage> createState() => _DeliveryProgressPageState();
}

class _DeliveryProgressPageState extends State<DeliveryProgressPage> {
  final List<String> steps = [
    'Book and Review',
    'Payment',
    'Delivery',
  ];
  Widget _buildItemCheckOutStep(
    int step,
    String nameStep,
    bool isEnd,
    bool isCheck,
  ) {
    return Row(
      children: [
        Container(
          width: kMediumPadding,
          height: kMediumPadding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(kMediumPadding),
            color: isCheck ? Colors.white : Colors.white.withOpacity(0.1),
          ),
          alignment: Alignment.center,
          child: Text(
            step.toString(),
            style: TextStyles.defaultStyle.copyWith(
              color: isCheck ? null : Colors.white,
            ),
          ),
        ),
        SizedBox(
          width: kMinPadding,
        ),
        Text(nameStep,
            style: TextStyles.defaultStyle.fontCaption.whiteTextColor),
        SizedBox(
          width: kMinPadding,
        ),
        if (!isEnd)
          SizedBox(
            width: kDefaultPadding,
            child: Divider(
              height: 1,
              thickness: 1,
              color: Colors.white,
            ),
          ),
        if (!isEnd)
          SizedBox(
            width: kMinPadding,
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      titleString: 'Bill progress',
      child: Column(
        children: [
          Row(
            children: steps
                .map((e) => _buildItemCheckOutStep(steps.indexOf(e) + 1, e, steps.indexOf(e) == steps.length - 1, steps.indexOf(e) == 2))
                .toList(),
          ),
          const SizedBox(height: 30),
          const Text("---------😍😍😍---------"),
          const Text("Thank you for booking!"),
          
          const SizedBox(height: 25),

          Container(
            decoration: BoxDecoration(
              border: Border.all(color: Theme.of(context).colorScheme.secondary),
              borderRadius: BorderRadius.circular(8),
            ),
            padding: const EdgeInsets.all(100),
            child: Text("Receipt here..."),
          ),

          Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ElevatedButton.icon(
                onPressed: () {
                  // Handle print receipt or other actions
                },
                icon: Icon(Icons.print),
                label: Text('Print'),
              ),
              ElevatedButton.icon(
                onPressed: () {
                  // Navigate back to the main app page
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => MainApp()),
                    (route) => false,
                  );
                },
                icon: Icon(Icons.home),
                label: Text('Home'),
              ),
            ],
          ),
          SizedBox(
            height: kMediumPadding,
          ),
        ],
      ),
    );
  }
}
