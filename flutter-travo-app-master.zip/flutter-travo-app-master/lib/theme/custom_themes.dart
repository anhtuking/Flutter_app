
import 'package:flutter/material.dart';

final lightTheme = ThemeData(
  brightness: Brightness.light,
  primarySwatch: Colors.blue,
  colorScheme: ColorScheme.light(
    secondary: Colors.blueAccent,
    inversePrimary: Colors.black,
  ),
);

final darkTheme = ThemeData(
  brightness: Brightness.dark,
  primarySwatch: Colors.blue,
  colorScheme: ColorScheme.dark(
    secondary: Colors.blueAccent,
    inversePrimary: Colors.white,
  ),
);