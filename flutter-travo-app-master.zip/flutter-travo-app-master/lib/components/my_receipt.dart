import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // for formatting date and time

class ReceiptPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final formattedDate = DateFormat('dd/MM/yyyy HH:mm (GMT+7)').format(now);

    return Scaffold(
      appBar: AppBar(
        title: Text('Receipt'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Travel App',
              style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10.0),
            Text('Date: $formattedDate'),
            SizedBox(height: 20.0),
            Text(
              'Thank you for using Travel App!',
              style: TextStyle(fontSize: 18.0),
            ),
            SizedBox(height: 20.0),
            Text(
              'Bill Details:',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10.0),
            // Add your dynamic bill details here
            // You can use Text widgets with formatted data for each field

            // Example bill details:
            /*
            Text('Service Type: Flight Booking'),
            Text('Service Name: Roundtrip Flight Hanoi - Da Nang'),
            Text('Quantity: 1'),
            Text('Price: 2,000,000 VND'),
            Text('Payment Method: Visa'),
            Text('Confirmation Code: 1234567890'),
            */

            SizedBox(height: 20.0),
            Text(
              'Please keep this receipt for your reference.',
              style: TextStyle(fontSize: 12.0),
            ),
            Text(
              'For any inquiries or support, please contact Travel App customer care at (Phone number) or (Email address).',
              style: TextStyle(fontSize: 12.0),
            ),
          ],
        ),
      ),
    );
  }
}