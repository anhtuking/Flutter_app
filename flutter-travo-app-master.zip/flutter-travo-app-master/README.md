# travo_app_source

A Flutter Application Travo booking hotel with pure UI. To run application

Step 1: Clone project to your computer

Step 2: Run "flutter pub get" in your terminal

Step 3: Choose Run and Debug

