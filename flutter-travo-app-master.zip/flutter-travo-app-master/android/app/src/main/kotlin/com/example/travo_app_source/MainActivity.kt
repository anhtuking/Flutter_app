package com.example.travo_app_source

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
